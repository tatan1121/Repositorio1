/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Chat;

import java.io.Serializable;

public class ClientePer implements Serializable{
    private String ip;
    private String Nick;
    private String Mensaje;
    private int puertodes;

   

    public int getPuertodes() {
        return puertodes;
    }
    
    public ClientePer() {
    }

   

    public void setPuertodes(int puertodes) {
        this.puertodes = puertodes;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setNick(String Nick) {
        this.Nick = Nick;
    }

    public void setMensaje(String Mensaje) {
        this.Mensaje = Mensaje;
    }

    public String getIp() {
        return ip;
    }

    public String getNick() {
        return Nick;
    }

    public String getMensaje() {
        return Mensaje;
    }
    
   
    
}
